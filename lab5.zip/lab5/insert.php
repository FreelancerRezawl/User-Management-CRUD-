<?php
include 'db.php';

$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];

$conn->query("INSERT INTO users (name, email, phone) VALUES ('$name', '$email', '$phone')");

header('Location: index.php');
?>
