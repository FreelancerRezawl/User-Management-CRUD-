<?php
include 'db.php';
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM users WHERE id = $id");
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container py-5">

<h2>Edit User</h2>

<form action="update.php" method="POST">
    <input type="hidden" name="id" value="<?= $row['id']; ?>">
    <input type="text" name="name" value="<?= $row['name']; ?>" class="form-control mb-2" required>
    <input type="email" name="email" value="<?= $row['email']; ?>" class="form-control mb-2" required>
    <input type="text" name="phone" value="<?= $row['phone']; ?>" class="form-control mb-2" required>
    <button type="submit" class="btn btn-primary">Update</button>
    <a href="index.php" class="btn btn-secondary">Cancel</a>
</form>

</body>
</html>
