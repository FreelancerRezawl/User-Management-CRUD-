<?php include 'db.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>PHP CRUD App</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container py-5">

<h2 class="mb-4">User Management (CRUD)</h2>

<!-- Add New User Form -->
<form action="insert.php" method="POST" class="mb-4">
    <input type="text" name="name" placeholder="Name" class="form-control mb-2" required>
    <input type="email" name="email" placeholder="Email" class="form-control mb-2" required>
    <input type="text" name="phone" placeholder="Phone" class="form-control mb-2" required>
    <button type="submit" class="btn btn-success">Add User</button>
</form>

<!-- User Table -->
<table class="table table-bordered">
    <thead>
        <tr>
            <th>Name</th><th>Email</th><th>Phone</th><th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php
    $result = $conn->query("SELECT * FROM users");
    while($row = $result->fetch_assoc()):
    ?>
    <tr>
        <td><?= $row['name']; ?></td>
        <td><?= $row['email']; ?></td>
        <td><?= $row['phone']; ?></td>
        <td>
            <a href="edit.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
            <a href="delete.php?id=<?= $row['id']; ?>" onclick="return confirm('Delete user?')" class="btn btn-danger btn-sm">Delete</a>
        </td>
    </tr>
    <?php endwhile; ?>
    </tbody>
</table>

</body>
</html>
